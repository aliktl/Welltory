from django.contrib import admin

# Register your models here.
from .models import Calculate, Correlation

admin.site.register(Calculate)


class CorrelationAdmin(admin.ModelAdmin):
    list_display = ['user_id', 'x_data_type', 'y_data_type', 'value', 'p_value']

admin.site.register(Correlation, CorrelationAdmin)
