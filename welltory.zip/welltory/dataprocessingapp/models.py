from django.db import models


# Create your models here.
class Calculate(models.Model):
    content_data = models.TextField()

class Correlation(models.Model):
    user_id = models.TextField()
    x_data_type = models.TextField()
    y_data_type = models.TextField()
    value = models.TextField()
    p_value = models.TextField()

