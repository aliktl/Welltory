from django.http import Http404
from django.shortcuts import render

# Create your views here.
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Calculate
import numpy as np
from scipy import stats
import json


@api_view(['GET'])
def getCalculate(request):
    if request.method == 'GET':
        user_id = request.GET.get('user_id')
        x_data_type = request.GET.get('x_data_type')
        y_data_type = request.GET.get('y_data_type')

        from .models import Correlation
        if Correlation.objects.filter(user_id=user_id, x_data_type=x_data_type,
                                      y_data_type=y_data_type).exists():
            object = Correlation.objects.get(user_id=user_id, x_data_type=x_data_type,
                                             y_data_type=y_data_type)
            value = object.value
            p_value = object.p_value
            res = {
                "user_id": int(user_id),
                "x_data_type": x_data_type,
                "y_data_type": y_data_type,
                "correlation": {
                    "value": float(value),
                    "p_value": float(p_value),
                }
            }
            return Response(res)
        elif Correlation.objects.filter(user_id=user_id, x_data_type=y_data_type,
                                        y_data_type=x_data_type).exists():
            object = Correlation.objects.get(user_id=user_id, x_data_type=y_data_type,
                                             y_data_type=x_data_type)
            value = object.value
            p_value = object.p_value
            res = {
                "user_id": int(user_id),
                "x_data_type": x_data_type,
                "y_data_type": y_data_type,
                "correlation": {
                    "value": float(value),
                    "p_value": float(p_value),
                }
            }
            return Response(res)
        else:
            raise Http404("Poll does not exist")


@api_view(['POST'])
def createCalculate(request):
    """The first step is to catch the post request method"""
    if request.method == 'POST':
        data = request.data
        """Here we start to calculate the metrics. First we collect all the dates which appear both x and y"""
        dates_x = set()
        dates_all = set()
        for i in data['data']['x']:
            if i['date'] not in dates_x:
                dates_x.add(i['date'])
        for i in data['data']['y']:
            if i['date'] in dates_x:
                dates_all.add(i['date'])
        x_values = []
        y_values = []
        for date in dates_all:
            for i in data['data']['x']:
                if i['date'] == date:
                    print(i['value'], type(i['value']))
                    x_values.append(i['value'])
            for j in data['data']['y']:
                if j['date'] == date:
                    y_values.append(j['value'])
        """Now we need to check the data since it can be null or wrong data type"""
        cnt = 0
        while cnt < len(x_values):
            if x_values[cnt] is None or (isinstance(x_values[cnt], (int, float)) == False) or y_values[cnt] is None or (
                    isinstance(y_values[cnt], (int, float)) == False):
                x_values.pop(cnt)
                y_values.pop(cnt)
            else:
                cnt += 1
        """We convert the collected arrays to numpy arrays"""
        x_simple = np.array(x_values)
        y_simple = np.array(y_values)
        value, p_value = stats.pearsonr(x_simple, y_simple)
        """For now we got and calculated the value and p value"""
        from .models import Correlation
        if Correlation.objects.filter(user_id=data['user_id'], x_data_type=data['data']['x_data_type'],
                                      y_data_type=data['data']['y_data_type']).exists():

            Correlation.objects.filter(user_id=data['user_id'], x_data_type=data['data']['x_data_type'],
                                       y_data_type=data['data']['y_data_type']).update(value=value, p_value=p_value)

        elif Correlation.objects.filter(user_id=data['user_id'], x_data_type=data['data']['y_data_type'],
                                        y_data_type=data['data']['x_data_type']).exists():
            Correlation.objects.filter(user_id=data['user_id'], x_data_type=data['data']['y_data_type'],
                                       y_data_type=data['data']['x_data_type']).update(value=value, p_value=p_value)
        else:
            new = Correlation(user_id=data['user_id'],
                              x_data_type=data['data']['x_data_type'],
                              y_data_type=data['data']['y_data_type'],
                              value=value,
                              p_value=p_value)
            new.save()
        return Response('The calculation is done and saved to database. Value: {}. P-value: {}'.format(value, p_value))
