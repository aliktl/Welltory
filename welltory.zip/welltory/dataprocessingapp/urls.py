from django.urls import path, include
from . import views

urlpatterns = [
    path('correlation/', views.getCalculate, name='get calculate'),
    path('calculate/', views.createCalculate, name='create calculate')
]
